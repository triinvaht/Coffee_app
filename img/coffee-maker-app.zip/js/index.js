const Screen = Vue.component("screen", {
  data() {
    return {
      title: "Default"
    };
  }
});

const Order = Vue.component("order", {
  extends: Screen,
  template: "#order",
  computed: {
    orderId: function(){
      return Math.floor(Math.random() * (100 - 1) ) + 1  
    },
    time: function(){
      return "5 Minutes"  
    },
  },
  data() {
    return {
      percentFoam: 50,
      slideOptions: {
        tooltip: false,
        height: 20,
        dotSize: 30,
        bgStyle: {
          backgroundColor: "#f7d388"
        },
        sliderStyle: {
          backgroundColor: "#fff"
        },
        processStyle: {
          backgroundColor: "#fff"
        }
      }
    };
  }
});

const Foam = Vue.component("foam", {
  extends: Screen,
  template: "#foam",
  components: {
    vueSlider: window["vue-slider-component"]
  },
  data() {
    return {
      percentFoam: 50,
      slideOptions: {
        tooltip: false,
        height: 20,
        dotSize: 30,
        bgStyle: {
          backgroundColor: "#f7d388"
        },
        sliderStyle: {
          backgroundColor: "#fff"
        },
        processStyle: {
          backgroundColor: "#fff"
        }
      }
    };
  }
});

const MilkBalance = Vue.component("MilkBalance", {
  extends: Screen,
  template: "#milkbalance",
  components: {
    vueSlider: window["vue-slider-component"]
  },
  data() {
    return {
      percentMilk: 50,
      slideOptions: {
        tooltip: false,
        height: 20,
        dotSize: 30,
        bgStyle: {
          backgroundColor: "#f7d388"
        },
        sliderStyle: {
          backgroundColor: "#fff"
        },
        processStyle: {
          backgroundColor: "#fff"
        }
      }
    };
  },

  methods: {
    itemSelected: function() {
      router.push("/foam");
    }
  }
});

const MilkType = Vue.component("MilkType", {
  extends: Screen,
  template: "#milktype",
  data() {
    return {
      choices: {
        small: {
          icon: "fa-coffee",
          text: "Cow"
        },
        medium: {
          icon: "fa-coffee",
          text: "Soy"
        },
        large: {
          icon: "fa-coffee",
          text: "Rice"
        },
        xl: {
          icon: "fa-coffee",
          text: "Coconut"
        }
      }
    };
  },
  methods: {
    itemSelected: function() {
      router.push("/milkbalance");
    }
  }
});

const Size = Vue.component("Size", {
  extends: Screen,
  template: "#size",
  data() {
    return {
      choices: {
        small: {
          icon: "fa-coffee",
          text: "Small"
        },
        medium: {
          icon: "fa-coffee",
          text: "Medium"
        },
        large: {
          icon: "fa-coffee",
          text: "Large"
        },
        xl: {
          icon: "fa-coffee",
          text: "XL"
        }
      }
    };
  },
  methods: {
    itemSelected: function() {
      router.push("/milktype");
    }
  }
});

const Home = Vue.component("Home", {
  extends: Screen,
  template: "#home",
});

const routes = [
  { path: "/", name: "Welcome", component: Home },
  { path: "/size", name: "Size", component: Size },
  { path: "/milktype", name: "Milk Type", component: MilkType },
  { path: "/milkbalance", name: "Milk Balance", component: MilkBalance },
  { path: "/foam", name: "Foam", component: Foam },
  { path: "/order", name: "Order Complete", component: Order }
];

const router = new VueRouter({
  routes
});

const app = new Vue({
  router,
  el: "#theApp",
  template: "#appTemplate",
  data(){
    return{
      title: "Welcome"
    };
  },
  watch: {
    '$route' (to, from) {
      this.title = to.name
    }
  }
});