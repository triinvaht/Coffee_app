A Pen created at CodePen.io. You can find this one at https://codepen.io/lifeventurer/pen/MZjQxN.

 A quick build of a Coffee Ordering App using VueJS. Original found here https://dribbble.com/shots/1920183-Coffee-Maker-App by Gal Shir (https://twitter.com/galgalshir). 